#pragma once
#include "PrimaryDataStorageElement.h"

class MatlabDataStorageElement : public PrimaryDataStorageElement
{
private:

public:



};