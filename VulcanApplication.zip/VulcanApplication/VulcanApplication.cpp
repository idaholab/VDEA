//2020-05-01 This application is responsible for taking the various different data formats that are used across the land and turning them into a different format

#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>
#include "CodexBus.h"
#include "DataInputManager.h"
#include "MessageHandlingSystem.h"
#include "CommandLineProcessor.h"
#include "PrimaryDataStorage.h"
#include "DataOutputManager.h"

#define Version "0.0"

using namespace std::chrono_literals;

int main(int argCount, char ** commandLineArgs)
{
	//Need a sophisticated command line tag handling system
	//	This is to handle the input and output selection system as well as the directories that the system will be going to
	//	This needs to spawn off and create the other systems that are required
	//	This current version needs to have the following components 
	//	recursive directory scanning
	//  interim file codex
	//  matlab codex
	//	TDMS Codex
	
	//This needs to be a thread spawning system?
	std::mutex overalMutex;
	std::condition_variable overallConditionVariable;
	bool run = false;
	
	MessageHandlingSystem * messageHandler = new MessageHandlingSystem();

	CodexBus * codexBus = new CodexBus();
	codexBus->initalizeCodexes();

	//if (!codexBus->initalizedSucessfully()) messageHandler->fatal(codexBus->getMessages());
	
	CommandLineArgumentSet * processedCommandLineArgs = CommandLineProcessor::processCommandLineArguments(messageHandler, codexBus,argCount, commandLineArgs);
	//check the plugin directory
	if (processedCommandLineArgs->pluginLocation != nullptr) codexBus->initializeCodexPlugins(processedCommandLineArgs->pluginLocation, messageHandler);

	

	if (CommandLineProcessor::checkCodexValues(codexBus,processedCommandLineArgs,messageHandler) && processedCommandLineArgs->commandsReadSucessfully())
	{
	
		//this is where the codex plugins need to be added

		if (processedCommandLineArgs->printCodexes)
		{
			codexBus->printAllCodexes(messageHandler);
		}
		else
		{
			PrimaryDataStorage * dataStorage = new PrimaryDataStorage();

			DataOutputManager * dataOutputManager = new DataOutputManager();
			dataOutputManager->setCommandLineArguments(processedCommandLineArgs);
			dataOutputManager->setDataStorage(dataStorage);
			dataOutputManager->setMessageHandlingSystem(messageHandler);
			dataOutputManager->setCodex(codexBus->getCodex(processedCommandLineArgs->outputCodex));
			dataOutputManager->setupThreading(&overalMutex, &overallConditionVariable, &run);

			DataInputManager * dataInputManager = new DataInputManager();
			dataInputManager->setCommandLineArguments(processedCommandLineArgs);
			dataInputManager->setDataStorage(dataStorage);
			dataInputManager->setCodex(codexBus->getCodex(processedCommandLineArgs->inputCodex));
			dataInputManager->setMessageHandlingSystem(messageHandler);
			dataInputManager->setupThreading(&overalMutex, &overallConditionVariable, &run);

			////Notifing all of the threads sitting on the condition variable will start the systems running
			run = true;
			overallConditionVariable.notify_all();
			//
			//messageHandler->operateErrorHandling();

			dataOutputManager->getThread()->join();
			dataInputManager->getThread()->join();

			delete processedCommandLineArgs;
			delete codexBus;
			delete dataStorage;
			delete dataOutputManager;
			delete dataInputManager;
		}
		//messageHandler->sendClosingMessage();
	}
	else
	{
		messageHandler->fatal("Missing full command line tags");
		if (processedCommandLineArgs->printCodexes)
		{
			codexBus->printAllCodexes(messageHandler);
		}
	}
	delete messageHandler;
}

